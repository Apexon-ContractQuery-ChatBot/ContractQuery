from configuration import openai_api_key,data_directory,parsed_txt_directory,vectorstore_dir
import os
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from langchain.chains import RetrievalQA
from langchain.llms import OpenAI
from langchain.chains.llm import LLMChain
from langchain.chains.combine_documents.stuff import StuffDocumentsChain
from langchain.prompts import PromptTemplate
from langchain.retrievers import ContextualCompressionRetriever
from langchain.retrievers.document_compressors import LLMChainExtractor
from langchain.vectorstores import Chroma
# Check if vectorstore exists, otherwise create one
def save_to_chroma(chunks,chunk_metadatas):
    if not os.path.exists(vectorstore_dir) or not os.listdir(vectorstore_dir):
        print("Vector store not found. Creating a new one...")
        embeddings = OpenAIEmbeddings(openai_api_key=openai_api_key)
        vectorstore = Chroma.from_texts(texts=chunks, embedding=embeddings, metadatas=chunk_metadatas, persist_directory=vectorstore_dir)
        vectorstore.persist()
        print("Vector store saved to local")
   
    return vectorstore

def load_from_chroma_langchain():
    if os.path.exists(vectorstore_dir):
        # Load the existing vector store via LangChain
        vectorstore = Chroma(persist_directory=vectorstore_dir,embedding_function=OpenAIEmbeddings(openai_api_key=openai_api_key))
        print(f"Vectorstore loaded from {vectorstore_dir}.")
        return vectorstore
    else:
        print("Vectorstore directory not found.")
        return None

# Create retriever
def retriever_system(vectorstore):
    retriever = vectorstore.as_retriever(search_type="similarity", search_k=3)

# Set up compressor for contextual compression
    llm = OpenAI(temperature=0, openai_api_key=openai_api_key)
    compressor = LLMChainExtractor.from_llm(llm)

# Create a contextual compression retriever
    compression_retriever = ContextualCompressionRetriever(
        base_compressor=compressor,
        base_retriever=retriever
        
    
    )
  
# Prompt template

    prompt_template = """
You are an advanced Contract Query Assistant. Your task is to accurately answer user queries based on the legal contract information provided in the context. Follow these rules to ensure the most precise and complete answer:

1. Use **only** the information from the provided context to answer the query. Do not make assumptions or refer to external knowledge.
2. If the query is unclear, break it down into logical parts, clarify each part based on the context, and then provide a complete answer.
3. If the provided context does not directly address the query, state: "The retrieved context does not contain sufficient information to answer the query."
4. If the context contains multiple relevant sections, summarize them succinctly and indicate how each part of the context relates to the query.
5. Where appropriate, provide references to specific sections, clauses, or page numbers within the context to support your answer.
6. Maintain a neutral, professional tone and avoid speculation.
7. For time-sensitive queries (e.g., contract duration or deadlines), ensure that your answer includes exact dates, timelines, or periods mentioned in the context.
8. If the query asks for a comparison or interpretation, provide a balanced explanation and highlight any potential ambiguities or exceptions in the contract.
9. If the query involves action items or obligations, clearly state who is responsible and when they are expected to fulfill their obligations based on the context.
10. If multiple options are possible (e.g., in case of contingencies or clauses with conditions), clearly explain the conditions under which each option applies.

Context (retrieved from documents): {context}

Query: {question}

Answer:
"""

# Create the QA chain with prompt, LLM, and retriever
    qa_prompt = PromptTemplate(template=prompt_template, input_variables=["context", "question"])
    llm_chain = LLMChain(llm=llm, prompt=qa_prompt)

    document_variable_name = "context"
    combine_documents_chain = StuffDocumentsChain(llm_chain=llm_chain, document_variable_name=document_variable_name)
    qa_chain = RetrievalQA(retriever=compression_retriever, combine_documents_chain=combine_documents_chain)
    return qa_chain
# Querying function
def query_system(query,qa_chain):
    result = qa_chain.run(query)
    elaborative_response = f"**Query:** {query}\n\n"
    elaborative_response += "**Relevant Information Found:**\n\n"
    elaborative_response += f"{result}\n\n"
    return elaborative_response
