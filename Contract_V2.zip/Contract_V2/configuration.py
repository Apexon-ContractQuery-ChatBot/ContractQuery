import os
openai_api_key = os.getenv("OPENAI_API_KEY")
data_directory = 'Synthetic.Data'
parsed_txt_directory = 'Trials'
vectorstore_dir = 'vectorstore2'
os.makedirs(parsed_txt_directory, exist_ok=True) 