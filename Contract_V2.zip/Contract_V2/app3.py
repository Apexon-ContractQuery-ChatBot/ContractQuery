from langchain_core.messages import AIMessage, HumanMessage
import os
import streamlit as st
from prepare_documents import prepare_docs, chunking, parse_files
from retrieval import save_to_chroma, retriever_system, query_system,load_from_chroma_langchain
from configuration import parsed_txt_directory, vectorstore_dir

# Function to load system and prepare data
def load():
    # Check if parsed_txt_directory is empty or doesn't exist
    if not os.path.exists(parsed_txt_directory) or len(os.listdir(parsed_txt_directory)) == 0:
        print("Parsed text directory is empty or missing. Parsing files...")
        parse_files()  # Trigger parsing of PDFs
    
    # Check if vectorstore exists, otherwise process embeddings
    if not os.path.exists(vectorstore_dir) or len(os.listdir(vectorstore_dir)) == 0:
        print("Vectorstore is empty or missing. Processing embeddings...")
        texts, metadatas = prepare_docs()
        chunks, chunk_metadatas = chunking(texts, metadatas)
        vectorstore = save_to_chroma(chunks, chunk_metadatas)
    else:
        print("Vectorstore exists. Loading it...")
        # Ensure the vectorstore is loaded if it exists
        vectorstore = load_from_chroma_langchain()# Load the existing vectorstore without recreating it
    
    qa_chain = retriever_system(vectorstore)
    return qa_chain

col1, mid, col2 = st.columns([1, 0.5, 1])

with mid:
    st.image("C:/Users/Shivani Gangarapollu/Downloads/Contract.png", width=70)

st.markdown("<h1 style='text-align: center;'>Contract Query Bot</h1>", unsafe_allow_html=True)

qa_chain = load()

if "chat_history" not in st.session_state:
    st.session_state.chat_history = [
        AIMessage(content="Hello, I am a Contract Query bot. How can I help you?"),
    ]

for message in st.session_state.chat_history:
    if isinstance(message, AIMessage):
        with st.chat_message("AI"):
            st.write(message.content)
    elif isinstance(message, HumanMessage):
        with st.chat_message("Human"):
            st.write(message.content)

user_query = st.chat_input("Enter your query about the contract:")

if user_query is not None:
    st.session_state.chat_history.append(HumanMessage(content=user_query))

    with st.chat_message("Human"):
        st.markdown(user_query)
        answer = query_system(user_query, qa_chain)
    
    with st.chat_message("AI"):
        response = answer
        st.write(response)
    
    st.session_state.chat_history.append(AIMessage(content=response))
else:
    st.write("")
